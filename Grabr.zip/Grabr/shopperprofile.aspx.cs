﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
namespace Grabr
{
    public partial class WebForm4 : System.Web.UI.Page
    {
        string strcon = ConfigurationManager.ConnectionStrings["con"].ConnectionString;
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                if (Session["UserType"].Equals("S"))
                {
                    Button1.Text = Session["UserID"].ToString();
                    Button2.Text = Session["FullName"].ToString();
                    Button3.Text = Session["ContactNo"].ToString();
                    Button4.Text = Session["Email"].ToString();
                    Button5.Text = Session["Country"].ToString();
                    Button6.Text = Session["Address"].ToString();

                }
                if (InProgressOrder())
                {
                    LinkButton1.Visible = false;
                }
                else
                {
                    LinkButton1.Visible = true;
                }
            }
            catch(Exception ex)
            {

            }
        }

        protected bool InProgressOrder()
        {
            DataSet ds = new DataSet();
            SqlConnection con = new SqlConnection(strcon);
            con.Open();

            try
            {
                if (con.State == ConnectionState.Closed)
                {
                    con.Open();

                }

                    SqlCommand cmd = new SqlCommand("lasttwoOrders", con);
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.Add("@ShopID", SqlDbType.VarChar, 3);
                    
                    cmd.Parameters.Add("@output_InProgressID", SqlDbType.Int).Direction = ParameterDirection.Output;
                    cmd.Parameters.Add("@output_secondRecentID", SqlDbType.Int).Direction = ParameterDirection.Output;

                    cmd.Parameters["@ShopID"].Value = Session["UserID"];
                   

                    cmd.ExecuteNonQuery();

                    int OID1 = Convert.ToInt32(cmd.Parameters["@output_InProgressID"].Value);
                    int OID2 = Convert.ToInt32(cmd.Parameters["@output_secondRecentID"].Value);

                con.Close();

                if (OID1 == -1)
                {
                    return false;
                }
                    return true;
             
               
            }
            catch (Exception ex)
            {
                
            }
            return false;
        }
    }

}