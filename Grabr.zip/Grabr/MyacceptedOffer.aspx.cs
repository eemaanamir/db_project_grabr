﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Grabr
{
    public partial class WebForm18 : System.Web.UI.Page
    {
        string strcon = ConfigurationManager.ConnectionStrings["con"].ConnectionString;
        protected void Page_Load(object sender, EventArgs e)
        {
            int OfferID = 0;
            int TID = Convert.ToInt32(Session["TID"]);
            string shopName = "";
            string offerStatus = "";
            int cost = 0;

            getmyAcceptedOffer(ref TID, ref OfferID);
            myofferDetails(ref OfferID, ref shopName, ref offerStatus, ref cost);

            LinkButton1.Text = OfferID.ToString();
            LinkButton2.Text = shopName;
            LinkButton3.Text = offerStatus;
            LinkButton4.Text = cost.ToString();
        }
        protected void getmyAcceptedOffer(ref int TripID, ref int OfferID)
        {
            DataSet ds = new DataSet();
            SqlConnection con = new SqlConnection(strcon);
            con.Open();
            try
            {
                if (con.State == ConnectionState.Closed)
                {
                    con.Open();

                }
                SqlCommand cmd = new SqlCommand("getmyAcceptedOffer", con);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.Add("@TripID", SqlDbType.Int);

                cmd.Parameters.Add("@output_OfferID", SqlDbType.Int).Direction = ParameterDirection.Output;

                cmd.Parameters["@TripID"].Value = TripID;
                cmd.ExecuteNonQuery();

                OfferID = Convert.ToInt32(cmd.Parameters["@output_OfferID"].Value);

                con.Close();

            }
            catch (Exception ex)
            {

            }

        }
        protected void myofferDetails(ref int OfferID, ref string ShopName, ref string offerStatus, ref int cost)
        {
            DataSet ds = new DataSet();
            SqlConnection con = new SqlConnection(strcon);
            con.Open();
            try
            {
                if (con.State == ConnectionState.Closed)
                {
                    con.Open();

                }
                SqlCommand cmd = new SqlCommand("myofferDetails", con);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.Add("@OfferID", SqlDbType.Int);

                cmd.Parameters.Add("@output_shopName", SqlDbType.VarChar, 50).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("@output_offerstatus", SqlDbType.VarChar, 15).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("@output_cost", SqlDbType.Int).Direction = ParameterDirection.Output;


                cmd.Parameters["@OfferID"].Value = OfferID;
                cmd.ExecuteNonQuery();

                ShopName = (String)cmd.Parameters["@output_shopName"].Value;
                offerStatus = (String)cmd.Parameters["@output_offerstatus"].Value;
                cost = Convert.ToInt32(cmd.Parameters["@output_cost"].Value);

                con.Close();

            }
            catch (Exception ex)
            {

            }
        }


    }
}