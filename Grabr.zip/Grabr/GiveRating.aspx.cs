﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Grabr
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        string strcon = ConfigurationManager.ConnectionStrings["con"].ConnectionString;
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        protected void buttonclick(object sender, EventArgs e)
        {
            DataSet ds = new DataSet();
            SqlConnection con = new SqlConnection(strcon);
            con.Open();

            try
            {
                if (con.State == ConnectionState.Closed)
                {
                    con.Open();

                }

                int OrderID = Convert.ToInt32(Session["OID"]);
                int Stars = 0;
                if (RadioButton1.Checked)
                {
                    Stars = 1;
                }
                else if (RadioButton2.Checked)
                {
                    Stars = 2;
                }
                else if (RadioButton3.Checked)
                {
                    Stars = 3;
                }
                else if (RadioButton4.Checked)
                {
                    Stars = 4;
                }
                else
                {
                    Stars = 5;
                }
                SqlCommand cmd = new SqlCommand("giveRating", con);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.Add("@OrderID", SqlDbType.Int);
                cmd.Parameters.Add("@Stars", SqlDbType.Int);

                cmd.Parameters["@OrderID"].Value = OrderID;
                cmd.Parameters["@Stars"].Value = Stars;


                cmd.ExecuteNonQuery();

                con.Close();
                Response.Redirect("Offeraccepted.aspx");

            }
            catch (Exception ex)
            {

            }
        }
    } 
}