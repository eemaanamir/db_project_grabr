﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Grabr
{
    public partial class WebForm14 : System.Web.UI.Page
    {
        string strcon = ConfigurationManager.ConnectionStrings["con"].ConnectionString;
        protected void Page_Load(object sender, EventArgs e)
        {
            int OfferID = 0;
            int OrderID = Convert.ToInt32(Session["OID"]);

            getAcceptedOffer(ref OrderID, ref OfferID);

            string TravName = "";
            int Rating = 0;
            DateTime date = new DateTime();
            int cost = 0;

            getOfferDetails(ref TravName, ref Rating, ref date, ref cost, ref OfferID);

            LinkButton1.Text = OfferID.ToString();
            LinkButton2.Text = TravName;
            LinkButton3.Text = Rating.ToString() + " Star";
            LinkButton4.Text = date.ToString("dd/M/yyyy");
            LinkButton5.Text = cost.ToString() + " Rs";

            if (ratingsGiven())
            {
                GiveRating.Visible = false;
            }
            else
            {
                GiveRating.Visible = true;
            }
        }
        protected void getOfferDetails(ref string TravNam, ref int Rating, ref DateTime date, ref int cost, ref int OfferID)
        {
            DataSet ds = new DataSet();
            SqlConnection con = new SqlConnection(strcon);
            con.Open();

            try
            {
                if (con.State == ConnectionState.Closed)
                {
                    con.Open();

                }

                SqlCommand cmd = new SqlCommand("getOfferDetails", con);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.Add("@OfferID", SqlDbType.Int);

                cmd.Parameters.Add("@output_travellerName", SqlDbType.VarChar, 50).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("@output_rating", SqlDbType.Int).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("@output_Date", SqlDbType.Date).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("@output_shippingCost", SqlDbType.Int).Direction = ParameterDirection.Output;

                cmd.Parameters["@OfferID"].Value = OfferID;


                cmd.ExecuteNonQuery();

                TravNam = (string)cmd.Parameters["@output_travellerName"].Value;
                Rating = Convert.ToInt32(cmd.Parameters["@output_rating"].Value);
                date = (DateTime)cmd.Parameters["@output_Date"].Value;
                cost = Convert.ToInt32(cmd.Parameters["@output_shippingCost"].Value);

                con.Close();


            }
            catch (Exception ex)
            {

            }
        }
        protected void getAcceptedOffer(ref int OrderID, ref int OfferID)
        {
            DataSet ds = new DataSet();
            SqlConnection con = new SqlConnection(strcon);
            con.Open();

            try
            {
                if (con.State == ConnectionState.Closed)
                {
                    con.Open();

                }

                SqlCommand cmd = new SqlCommand("getAcceptedOfferID", con);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.Add("@OrderID", SqlDbType.Int);


                cmd.Parameters.Add("@output_OfferID", SqlDbType.Int).Direction = ParameterDirection.Output;


                cmd.Parameters["@OrderID"].Value = OrderID;


                cmd.ExecuteNonQuery();

                OfferID = Convert.ToInt32(cmd.Parameters["@output_OfferID"].Value);


                con.Close();


            }
            catch (Exception ex)
            {

            }
        }

        protected bool ratingsGiven()
        {
            DataSet ds = new DataSet();
            SqlConnection con = new SqlConnection(strcon);
            con.Open();

            try
            {
                if (con.State == ConnectionState.Closed)
                {
                    con.Open();

                }

                int OrderID = Convert.ToInt32(Session["OID"]);

                SqlCommand cmd = new SqlCommand("ratingGiven", con);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.Add("@OrderID", SqlDbType.Int);
                cmd.Parameters.Add("@flag", SqlDbType.Int).Direction = ParameterDirection.Output;

                cmd.Parameters["@OrderID"].Value = OrderID;
                cmd.ExecuteNonQuery();

                int flag = Convert.ToInt32(cmd.Parameters["@flag"].Value);

                if (flag == 0)
                {
                    return false;
                }
                return true;

                con.Close();

            }
            catch (Exception ex)
            {

            }
            return false;
        }
    }
}
