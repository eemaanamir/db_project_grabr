﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Grabr
{
    public partial class WebForm11 : System.Web.UI.Page
    {
        string strcon = ConfigurationManager.ConnectionStrings["con"].ConnectionString;
        int TID1 = 0;
        int TID2 = 0;
       
        protected void Page_Load(object sender, EventArgs e)
        {
            lasttwoTrips(ref TID1, ref TID2);
            string Country1 = "";
            string Arrivaldate1 = "";
            int totalRevenue1 = 0;
            string tripStatus1 = "";


            string Country2 = "";
            string Arrivaldate2 = "";
            int totalRevenue2 = 0;
            string tripStatus2 = "";

            getTripDetails(ref TID1, ref Country1, ref Arrivaldate1, ref totalRevenue1, ref tripStatus1);
            getTripDetails(ref TID2, ref Country2, ref Arrivaldate2, ref totalRevenue2, ref tripStatus2);

            Button1.Text = TID1.ToString();
            Button2.Text = Arrivaldate1;
            Button3.Text = Country1;

            Button4.Text = TID2.ToString();
            Button5.Text = Arrivaldate2;
            Button6.Text = Country2;


        }
        protected void SpecificTrip1_Click(object sender, EventArgs e)
        {
            Session["TID"] = TID1.ToString();
            Response.Redirect("specifictriphistory.aspx");
        }
        protected void SpecificTrip2_Click(object sender, EventArgs e)
        {
            Session["TID"] = TID2.ToString();
            Response.Redirect("specifictriphistory.aspx");
        }
        protected bool lasttwoTrips(ref int TID1 , ref int TID2)
        {
            DataSet ds = new DataSet();
            SqlConnection con = new SqlConnection(strcon);
            con.Open();

            try
            {
                if (con.State == ConnectionState.Closed)
                {
                    con.Open();
                }
                SqlCommand cmd = new SqlCommand("lasttwoTrips", con);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.Add("@TravID", SqlDbType.VarChar, 3);

                cmd.Parameters.Add("@output_InProgressID", SqlDbType.Int).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("@output_secondRecentID", SqlDbType.Int).Direction = ParameterDirection.Output;

                cmd.Parameters["@TravID"].Value = Session["UserID"];


                cmd.ExecuteNonQuery();

                TID1 = Convert.ToInt32(cmd.Parameters["@output_InProgressID"].Value);
                TID2 = Convert.ToInt32(cmd.Parameters["@output_secondRecentID"].Value);

                con.Close();

                if (TID1 == -1)
                {
                    return false;
                }
                return true;


            }
            catch (Exception ex)
            {

            }
            return false;
        }
        protected void getTripDetails(ref int TripID, ref String Country, ref string ArrivalDate, ref int totalRevenue, ref string tripStatus)
        {
            DataSet ds = new DataSet();
            SqlConnection con = new SqlConnection(strcon);
            con.Open();

            try
            {
                if (con.State == ConnectionState.Closed)
                {
                    con.Open();

                }
                SqlCommand cmd = new SqlCommand("getTripDetails", con);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.Add("@TripID", SqlDbType.Int);


                cmd.Parameters.Add("@output_Country", SqlDbType.VarChar, 60).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("@output_Arrival_date", SqlDbType.VarChar, 10).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("@output_TotalRevenue", SqlDbType.Int).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("@output_tripstatus", SqlDbType.VarChar, 15).Direction = ParameterDirection.Output;
                
                cmd.Parameters["@TripID"].Value = TripID;
                cmd.ExecuteNonQuery();
                
                Country = (String)cmd.Parameters["@output_Country"].Value;
                ArrivalDate = (String)cmd.Parameters["@output_Arrival_date"].Value;
                totalRevenue = Convert.ToInt32(cmd.Parameters["@output_TotalRevenue"].Value);
                tripStatus = (String)cmd.Parameters["@output_tripstatus"].Value;

                con.Close();

            }
            catch (Exception ex)
            {

            }

        }

    }
}