﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Grabr
{
    public partial class WebForm16 : System.Web.UI.Page
    {
        string strcon = ConfigurationManager.ConnectionStrings["con"].ConnectionString;
        int OrderID1 = 0;
        int OrderID2 = 0;
        protected void Page_Load(object sender, EventArgs e)
        {
            int TripID = Convert.ToInt32(Session["TID"]);
            getOrderIDs(ref TripID, ref OrderID1, ref OrderID2);

            String ProductName1 = "";
            int ProductCost1 = 0;
            int totalCost = 0;
            string OrderStatus = "";
            String PaymentStatus = "";


            String ProductName2 = "";
            int ProductCost2 = 0;

            if(OrderID1 != -1)
            {
                getOrderDetails(ref OrderID1, ref ProductName1, ref ProductCost1, ref totalCost, ref OrderStatus, ref PaymentStatus);
                LinkButton1.Text = OrderID1.ToString();
                LinkButton2.Text = ProductName1;
                LinkButton3.Text = ProductCost1.ToString();
                makeoffer1.Visible = true;
            }
            else
            {
                LinkButton1.Text = "N/A";
                LinkButton2.Text = "N/A";
                LinkButton3.Text = "N/A";
                makeoffer1.Visible = false;
            }
            if (OrderID2 != -1)
            {
                getOrderDetails(ref OrderID2, ref ProductName2, ref ProductCost2, ref totalCost, ref OrderStatus, ref PaymentStatus);
                LinkButton5.Text = OrderID2.ToString();
                LinkButton6.Text = ProductName2;
                LinkButton7.Text = ProductCost2.ToString();
                makeoffer2.Visible = true;
            }
            else
            {
                LinkButton5.Text = "N/A";
                LinkButton6.Text = "N/A";
                LinkButton7.Text = "N/A";
                makeoffer2.Visible = false;
            }

        }
        protected void makeoffer1_Click(object sender, EventArgs e)
        {
            Session["makeOffer"] = OrderID1.ToString();
            Response.Redirect("MakeOffer.aspx");
        }
        protected void makeoffer2_Click(object sender, EventArgs e)
        {
            Session["makeOffer"] = OrderID2.ToString();
            Response.Redirect("MakeOffer.aspx");
        }
        protected void getOrderIDs(ref int TripID , ref int OrderID1, ref int OrderID2)
        {
            DataSet ds = new DataSet();
            SqlConnection con = new SqlConnection(strcon);
            con.Open();
            try
            {
                if (con.State == ConnectionState.Closed)
                {
                    con.Open();

                }
                SqlCommand cmd = new SqlCommand("toptwoOrders", con);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.Add("@TripID", SqlDbType.Int);

                cmd.Parameters.Add("@output_OrderID1", SqlDbType.Int).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("@output_OrderID2", SqlDbType.Int).Direction = ParameterDirection.Output;

                cmd.Parameters["@TripID"].Value = TripID;
                cmd.ExecuteNonQuery();

                OrderID1 = Convert.ToInt32(cmd.Parameters["@output_OrderID1"].Value);
                OrderID2 = Convert.ToInt32(cmd.Parameters["@output_OrderID2"].Value);

                con.Close();

            }
            catch (Exception ex)
            {

            }

        }
        protected void getOrderDetails(ref int OrderID, ref String ProductName, ref int ProductCost, ref int totalCost, ref string OrderStatus, ref String PaymentStatus)
        {
            DataSet ds = new DataSet();
            SqlConnection con = new SqlConnection(strcon);
            con.Open();

            try
            {
                if (con.State == ConnectionState.Closed)
                {
                    con.Open();

                }
                SqlCommand cmd = new SqlCommand("getOrderDetails", con);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.Add("@OrderID", SqlDbType.Int);


                cmd.Parameters.Add("@output_ProductName", SqlDbType.VarChar, 60).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("@output_ProductCost", SqlDbType.Int).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("@output_totalCost", SqlDbType.Int).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("@output_OrderStatus", SqlDbType.VarChar, 15).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("@output_PaymentStatus", SqlDbType.VarChar, 15).Direction = ParameterDirection.Output;


                cmd.Parameters["@OrderID"].Value = OrderID;
                cmd.ExecuteNonQuery();

                ProductName = (String)cmd.Parameters["@output_ProductName"].Value;
                ProductCost = Convert.ToInt32(cmd.Parameters["@output_ProductCost"].Value);
                totalCost = Convert.ToInt32(cmd.Parameters["@output_totalCost"].Value);
                OrderStatus = (String)cmd.Parameters["@output_OrderStatus"].Value;
                PaymentStatus = (String)cmd.Parameters["@output_PaymentStatus"].Value;

                con.Close();

            }
            catch (Exception ex)
            {

            }

        }
    }
}