﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Grabr
{

    public partial class WebForm12 : System.Web.UI.Page
    {
        string strcon = ConfigurationManager.ConnectionStrings["con"].ConnectionString;

        protected void Page_Load(object sender, EventArgs e)
        {
            string ProductName = "";
            int ProductCost = 0;
            int totalCost = 0;
            string orderStatus = "";
            string PaymentStatus = "";
            int OrderID = Convert.ToInt32(Session["OID"]);

            getOrderDetails(ref OrderID, ref ProductName,ref ProductCost,ref totalCost,ref orderStatus,ref PaymentStatus);

            LinkButton0.Text = OrderID.ToString();
            LinkButton1.Text = ProductName;
            LinkButton2.Text = ProductCost.ToString();
            LinkButton3.Text = totalCost.ToString();
            LinkButton4.Text = orderStatus;
            LinkButton5.Text = PaymentStatus;

            if(orderStatus == "Pending")
            {
                OfferMade.Visible = true;
                OffersAccepted.Visible = false;
            }
            else 
            {
                OfferMade.Visible = false;
                OffersAccepted.Visible = true;
            }
            if(orderStatus != "Completed")
            {
                OrderRecieved.Visible = true;
            }
            else
            {
                OrderRecieved.Visible = false;
            }

            if(PaymentStatus != "Paid")
            {
                MakePayment.Visible = true;
            }
            else
            {
                MakePayment.Visible = false;
            }
           
        }

        protected void getOrderDetails(ref int OrderID , ref String ProductName , ref int ProductCost , ref int totalCost , ref string OrderStatus , ref String PaymentStatus)
        {
            DataSet ds = new DataSet();
            SqlConnection con = new SqlConnection(strcon);
            con.Open();

            try
            {
                if (con.State == ConnectionState.Closed)
                {
                    con.Open();

                }
                    SqlCommand cmd = new SqlCommand("getOrderDetails", con);
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.Add("@OrderID", SqlDbType.Int);
                    

                    cmd.Parameters.Add("@output_ProductName", SqlDbType.VarChar,60).Direction = ParameterDirection.Output;
                    cmd.Parameters.Add("@output_ProductCost", SqlDbType.Int).Direction = ParameterDirection.Output;
                    cmd.Parameters.Add("@output_totalCost", SqlDbType.Int).Direction = ParameterDirection.Output;
                    cmd.Parameters.Add("@output_OrderStatus", SqlDbType.VarChar,15).Direction = ParameterDirection.Output;
                    cmd.Parameters.Add("@output_PaymentStatus", SqlDbType.VarChar,15).Direction = ParameterDirection.Output;


                    cmd.Parameters["@OrderID"].Value = OrderID;
                    cmd.ExecuteNonQuery();
                    
                    ProductName = (String)cmd.Parameters["@output_ProductName"].Value;
                    ProductCost = Convert.ToInt32(cmd.Parameters["@output_ProductCost"].Value);
                    totalCost = Convert.ToInt32(cmd.Parameters["@output_totalCost"].Value);
                    OrderStatus = (String)cmd.Parameters["@output_OrderStatus"].Value;
                    PaymentStatus = (String)cmd.Parameters["@output_PaymentStatus"].Value;

                    con.Close();
             
            }
            catch (Exception ex)
            {

            }
        
        }
        protected void Confirm_Order_Recieved(object sender, EventArgs e)
        {
            DataSet ds = new DataSet();
            SqlConnection con = new SqlConnection(strcon);
            con.Open();

            try
            {
                if (con.State == ConnectionState.Closed)
                {
                    con.Open();

                }
                SqlCommand cmd = new SqlCommand("orderRecieved", con);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.Add("@OrderID", SqlDbType.Int);

                cmd.Parameters["@OrderID"].Value = Session["OID"];
                cmd.ExecuteNonQuery();

                Response.Redirect("SpecificOrderHistory.aspx");

                con.Close();

            }
            catch (Exception ex)
            {

            }


        }

        protected void Make_Payment(object sender, EventArgs e)
        {
            DataSet ds = new DataSet();
            SqlConnection con = new SqlConnection(strcon);
            con.Open();

            try
            {
                if (con.State == ConnectionState.Closed)
                {
                    con.Open();

                }
                SqlCommand cmd = new SqlCommand("makePayment", con);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.Add("@OrderID", SqlDbType.Int);

                cmd.Parameters["@OrderID"].Value = Session["OID"];
                cmd.ExecuteNonQuery();

                Response.Redirect(Request.RawUrl);

                con.Close();

            }
            catch (Exception ex)
            {

            }


        }
    }
}