﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Grabr
{
    public partial class WebForm17 : System.Web.UI.Page
    {
        string strcon = ConfigurationManager.ConnectionStrings["con"].ConnectionString;
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        protected void button2_click(object sender, EventArgs e)
        {
            int OrderID = Convert.ToInt32(Session["makeOffer"]);
            int TripID = Convert.ToInt32(Session["TID"]);
            int shippingCost = Convert.ToInt32(TextBox2.Text.Trim());
            make_Offer(ref OrderID, ref TripID, ref shippingCost);


        }
        protected void make_Offer(ref int OrderID, ref int TripID, ref int ShippingCost)
        {
            DataSet ds = new DataSet();
            SqlConnection con = new SqlConnection(strcon);
            con.Open();
            try
            {
                if (con.State == ConnectionState.Closed)
                {
                    con.Open();

                }
                SqlCommand cmd = new SqlCommand("makeOffer", con);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.Add("@TripID", SqlDbType.Int);
                cmd.Parameters.Add("@OrderID", SqlDbType.Int);
                cmd.Parameters.Add("@shipping_cost", SqlDbType.Int);

                cmd.Parameters["@TripID"].Value = TripID;
                cmd.Parameters["@OrderID"].Value = OrderID;
                cmd.Parameters["@shipping_cost"].Value = ShippingCost;

                cmd.ExecuteNonQuery();
                Response.Write("<script>alert('Offer Successfully Made');</script>");
                Response.Redirect("specifictriphistory.aspx");

                con.Close();

            }
            catch (Exception ex)
            {

            }
        }


    }
}