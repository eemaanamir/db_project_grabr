﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Grabr
{
    public partial class Site1 : System.Web.UI.MasterPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                if (Session["UserType"].Equals(""))
                {
                    LinkButton0.Visible = true;  // home
                    LinkButton1.Visible = true;  //Login
                    LinkButton2.Visible = true;  // SIgn up
                    LinkButton7.Visible = false;  // shopper profile
                    LinkButton3.Visible = false;  // traveller profile
                    LinkButton8.Visible = false;  // Sign out
                }
                else if (Session["UserType"].Equals("T"))
                {
                    LinkButton0.Visible = true;  // home
                    LinkButton1.Visible = false;  //Login
                    LinkButton2.Visible = false;  // SIgn up
                    LinkButton7.Visible = false;  // shopper profile
                    LinkButton3.Visible = true;  // traveller profile
                    LinkButton8.Visible = true;  // Sign out
                }
                else if (Session["UserType"].Equals("S"))
                {
                    LinkButton0.Visible = true;  // home
                    LinkButton1.Visible = false;  //Login
                    LinkButton2.Visible = false;  // SIgn up
                    LinkButton7.Visible = true;  // shopper profile
                    LinkButton3.Visible = false;  // traveller profile
                    LinkButton8.Visible = true;  // Sign out
                }
            }
            catch (Exception ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
        }
        protected void LinkButton8_Click(object sender, EventArgs e)  /// SIgn out
        {
            Session["UserID"] = "";
            Session["UserType"] = "";
            Session["FullName"] = "";
            Session["Email"] = "";
            Session["ContactNo"] = "";
            Session["Country"] = "";
            Session["Address"] = "";
            Session["Password"] = "";

            LinkButton0.Visible = true;  // home
            LinkButton1.Visible = true;  //Login
            LinkButton2.Visible = true;  // SIgn up
            LinkButton7.Visible = false;  // shopper profile
            LinkButton3.Visible = false;  // traveller profile
            LinkButton8.Visible = false;  // Sign out
            Response.Redirect("homepage.aspx");
        }
    }
}