﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Grabr
{
    public partial class WebForm7 : System.Web.UI.Page
    {
        string strcon = ConfigurationManager.ConnectionStrings["con"].ConnectionString;
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                if (Session["UserType"].Equals("T"))
                {
                    TButton1.Text = Session["UserID"].ToString();
                    TButton2.Text = Session["FullName"].ToString();
                    TButton3.Text = Session["ContactNo"].ToString();
                    TButton4.Text = Session["Email"].ToString();
                    TButton5.Text = Session["Country"].ToString();
                    TButton6.Text = Session["Address"].ToString();
                }
                
                if (InProgressTrip())
                {
                    planNewTrip.Visible = false;
                }
                else
                {
                    planNewTrip.Visible = true;
                }
            }
            catch (Exception ex)
            {

            }
        }
        protected bool InProgressTrip()
        {
            DataSet ds = new DataSet();
            SqlConnection con = new SqlConnection(strcon);
            con.Open();

            try
            {
                if (con.State == ConnectionState.Closed)
                {
                    con.Open();

                }

                SqlCommand cmd = new SqlCommand("lasttwoTrips", con);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.Add("@TravID", SqlDbType.VarChar, 3);

                cmd.Parameters.Add("@output_InProgressID", SqlDbType.Int).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("@output_secondRecentID", SqlDbType.Int).Direction = ParameterDirection.Output;

                cmd.Parameters["@TravID"].Value = Session["UserID"];


                cmd.ExecuteNonQuery();

                int TID1 = Convert.ToInt32(cmd.Parameters["@output_InProgressID"].Value);
                int TID2 = Convert.ToInt32(cmd.Parameters["@output_secondRecentID"].Value);

                con.Close();

                if (TID1 == -1)
                {
                    return false;
                }
                return true;


            }
            catch (Exception ex)
            {

            }
            return false;
        }
        
    }
}