﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Grabr
{

    public partial class WebForm5 : System.Web.UI.Page
    {

        string strcon = ConfigurationManager.ConnectionStrings["con"].ConnectionString;
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        bool checkMemberExists()
        {
            try
            {
                SqlConnection con = new SqlConnection(strcon);
                if (con.State == ConnectionState.Closed)
                {
                    con.Open();
                }
                SqlCommand cmd = new SqlCommand("SELECT * from users where UserID='" + TextBox1.Text.Trim() + "'and [Password]='" + TextBox2.Text.Trim() + "';", con);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                if (dt.Rows.Count >= 1)
                {
                    Session["UserID"] = TextBox1.Text.Trim();
                    Session["Password"] = TextBox2.Text.Trim();
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch (Exception ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
                return false;
            }
        }
        //protected void Button1_Click(object sender, EventArgs e)
        //{
        //    try
        //    {
        //        SqlConnection con = new SqlConnection(strcon);
        //        if (con.State == ConnectionState.Closed)
        //        {
        //            con.Open();

        //        }
        //        SqlCommand cmd = new SqlCommand("select * from users where UserID='" + TextBox1.Text.Trim() + "' AND password='" + TextBox2.Text.Trim() + "'", con);
        //        SqlDataReader dr = cmd.ExecuteReader();
        //        if (dr.HasRows)
        //        {
        //            while (dr.Read())
        //            {
        //                Response.Write("<script>alert('Login Succesfull');</script>");
        //                //Response.Write("<script>alert('Logged IN ');</script>");
        //                Session["UserID"] = dr.GetValue(0).ToString();
        //                Session["UserType"] = dr.GetValue(1).ToString();
        //                Session["FullName"] = dr.GetValue(2).ToString();
        //                Session["Email"] = dr.GetValue(3).ToString();
        //                Session["ContactNo"] = dr.GetValue(4).ToString();
        //                Session["Country"] = dr.GetValue(5).ToString();
        //                Session["Address"] = dr.GetValue(6).ToString();
        //                Session["Password"] = dr.GetValue(7).ToString();
        //            }
        //            if (Session["UserType"].Equals("T"))
        //            {
        //                Response.Redirect("travellerprofile.aspx");
        //            }
        //            else if (Session["UserType"].Equals("S"))
        //            {
        //                Response.Redirect("shopperprofile.aspx");
        //            }

        //        }
        //        else
        //        {
        //            Response.Write("<script>alert('Invalid credentials');</script>");
        //        }

        //    }
        //    catch (Exception ex)
        //    {

        //    }
        //}

        // user login


        protected void Button1_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = new SqlConnection(strcon);
                if (con.State == ConnectionState.Closed)
                {
                    con.Open();

                }
                if (checkMemberExists())
                {
                    String UserID = Session["UserID"].ToString();
                    String UserType = "";
                    String FullName = "";
                    String Email = "";
                    String ContactNo = "";
                    String Country = "";
                    String Address = "";
                    String Password = Session["Password"].ToString();

                    LoginProcedure(ref UserID, ref UserType, ref Password);

                    Response.Write("<script>alert('Login Succesfull');</script>");
                    Session["UserID"] = UserID;
                    Session["UserType"] = UserType;
                    Session["Password"] = Password;

                    setSession(ref UserID, ref Password);

                    if (Session["UserType"].Equals("T"))
                    {
                        Response.Redirect("travellerprofile.aspx");
                    }
                    else if (Session["UserType"].Equals("S"))
                    {
                        Response.Redirect("shopperprofile.aspx");
                    }
                }
                else
                {
                    Response.Write("<script>alert('Invalid credentials');</script>");
                }

            }
            catch (Exception ex)
            {

            }
        }

        protected void setSession(ref String UserID, ref String Password)
        {
            try
            {
                SqlConnection con = new SqlConnection(strcon);
                if (con.State == ConnectionState.Closed)
                {
                    con.Open();

                }
                SqlCommand cmd = new SqlCommand("select * from users where UserID='" + UserID + "' AND password='" + Password + "'", con);
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    while (dr.Read())
                    {
                        Session["FullName"] = dr.GetValue(2).ToString();
                        Session["Email"] = dr.GetValue(3).ToString();
                        Session["ContactNo"] = dr.GetValue(4).ToString();
                        Session["Country"] = dr.GetValue(5).ToString();
                        Session["Address"] = dr.GetValue(6).ToString();
                    }
                }
            }
            catch (Exception ex)
            {

            }
        }
        protected void LoginProcedure(ref String UserID, ref String UserType, ref String Password)
        {
            DataSet ds = new DataSet();
            SqlConnection con = new SqlConnection(strcon);
            con.Open();

            try
            {
                if (con.State == ConnectionState.Closed)
                {
                    con.Open();

                }
                if (checkMemberExists())
                {

                    SqlCommand cmd = new SqlCommand("NewLogin", con);
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.Add("@UserID", SqlDbType.VarChar, 3);
                    cmd.Parameters.Add("@Password", SqlDbType.VarChar, 8);

                    cmd.Parameters.Add("@myout", SqlDbType.Int).Direction = ParameterDirection.Output;

                    cmd.Parameters.Add("@output_UserType", SqlDbType.VarChar, 1).Direction = ParameterDirection.Output;

                    cmd.Parameters["@UserID"].Value = UserID;
                    cmd.Parameters["@Password"].Value = Password;


                    cmd.ExecuteNonQuery();

                    int Found = Convert.ToInt32(cmd.Parameters["@myout"].Value);
                    String temp = (String)cmd.Parameters["@output_UserType"].Value;

                    UserType = temp;

                    con.Close();

                }
            }
            catch (Exception ex)
            {

            }
        }
    }
}