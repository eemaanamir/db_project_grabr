﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Grabr
{
    public partial class WebForm10 : System.Web.UI.Page
    {
        int OID1 = 0;
        int OID2 = 0;
        string strcon = ConfigurationManager.ConnectionStrings["con"].ConnectionString;
        protected void Page_Load(object sender, EventArgs e)
        {

            LastTwoOrders(ref OID1, ref OID2);
            string status1 = "";
            string status2 = "";
            if (OID1 != -1)
            {
                getOrderStatus(ref status1, ref OID1);
            }
            else {
                status1 = "N/A";
            }
            if (OID2 != -1)
            {
                getOrderStatus(ref status2, ref OID2);
            }
            else
            {
                status2 = "N/A";
            }

            if(OID1 == -1)
            {
                LinkButton1.Text = "N/A";
            }
            else
            {
                LinkButton1.Text = OID1.ToString();
            }
            if (OID2 == -1)
            {
                LinkButton3.Text = "N/A";
            }
            else
            {
                LinkButton3.Text = OID2.ToString();
            }
            LinkButton2.Text = status1;
            LinkButton4.Text = status2;


        }
        protected void SpecificHistory1_Click(object sender, EventArgs e)
        {
            Session["OID"] = OID1.ToString();
            Response.Redirect("SpecificOrderHistory.aspx");
        }
        protected void SpecificHistory2_Click(object sender, EventArgs e)
        {
            Session["OID"] = OID2.ToString();
            Response.Redirect("SpecificOrderHistory.aspx");
        }
        protected void getOrderStatus(ref string status, ref int OrderID)
        {
            DataSet ds = new DataSet();
            SqlConnection con = new SqlConnection(strcon);
            con.Open();

            try
            {
                if (con.State == ConnectionState.Closed)
                {
                    con.Open();

                }

                SqlCommand cmd = new SqlCommand("getOrderStatus", con);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.Add("@OrderID", SqlDbType.Int);

                cmd.Parameters.Add("@output_orderStatus", SqlDbType.VarChar,(15)).Direction = ParameterDirection.Output;


                cmd.Parameters["@OrderID"].Value = OrderID;


                cmd.ExecuteNonQuery();

                String temp = (String)cmd.Parameters["@output_orderStatus"].Value;

                status = temp;
                con.Close();


            }
            catch (Exception ex)
            {

            }
        }
        protected void LastTwoOrders(ref int OID1, ref int OID2)
        {
            DataSet ds = new DataSet();
            SqlConnection con = new SqlConnection(strcon);
            con.Open();

            try
            {
                if (con.State == ConnectionState.Closed)
                {
                    con.Open();

                }

                SqlCommand cmd = new SqlCommand("lasttwoOrders", con);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.Add("@ShopID", SqlDbType.VarChar, 3);

                cmd.Parameters.Add("@output_InProgressID", SqlDbType.Int).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("@output_secondRecentID", SqlDbType.Int).Direction = ParameterDirection.Output;

                cmd.Parameters["@ShopID"].Value = Session["UserID"];


                cmd.ExecuteNonQuery();

                 OID1 = Convert.ToInt32(cmd.Parameters["@output_InProgressID"].Value);
                 OID2 = Convert.ToInt32(cmd.Parameters["@output_secondRecentID"].Value);

                con.Close();


            }
            catch (Exception ex)
            {

            }
        }
    
    }
}