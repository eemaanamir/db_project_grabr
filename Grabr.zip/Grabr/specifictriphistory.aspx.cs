﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Grabr
{
    public partial class WebForm15 : System.Web.UI.Page
    {
        string strcon = ConfigurationManager.ConnectionStrings["con"].ConnectionString;
        int OfferID = 0;
        protected void Page_Load(object sender, EventArgs e)
        {
            int TID = Convert.ToInt32(Session["TID"]);

            string Country = "";
            string Arrivaldate = "";
            int totalRevenue = 0;
            string tripStatus = "";

            getTripDetails(ref TID, ref Country,ref Arrivaldate, ref totalRevenue, ref tripStatus);

            LinkButton1.Text = TID.ToString();
            LinkButton2.Text = Country;
            LinkButton3.Text = Arrivaldate;
            LinkButton4.Text = totalRevenue.ToString();
            LinkButton5.Text = tripStatus;

            
            getmyAcceptedOffer(ref TID, ref OfferID);

            if(OfferID == -1)
            {
                MyAcceptedOffer.Visible = false;
                MakenewOffer.Visible = true;

            }
            else
            {
                MyAcceptedOffer.Visible = true;
                MakenewOffer.Visible = false;
            }
            if(tripStatus == "Finished")
            {
                FinishTrip.Visible = false;
            }
            else
            {
                FinishTrip.Visible = true;
            }
            int flag = 0;
            getPaymentStatus(ref OfferID, ref flag);

            if (flag == 1)
            {
                RecievePayment.Visible = true;
            }
            else
            {
                RecievePayment.Visible = false;
            }
        }
        protected void getPaymentStatus(ref int OfferID , ref int flag)
        {
            DataSet ds = new DataSet();
            SqlConnection con = new SqlConnection(strcon);
            con.Open();

            try
            {
                if (con.State == ConnectionState.Closed)
                {
                    con.Open();

                }
                SqlCommand cmd = new SqlCommand("getPaymentStatus", con);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.Add("@OfferID", SqlDbType.Int);


                cmd.Parameters.Add("@output_flag", SqlDbType.Int).Direction = ParameterDirection.Output;

                cmd.Parameters["@OfferID"].Value = OfferID;
                cmd.ExecuteNonQuery();

                flag = Convert.ToInt32(cmd.Parameters["@output_flag"].Value);
                

                con.Close();

            }
            catch (Exception ex)
            {

            }

        }
        protected void recievePayment_click(object sender, EventArgs e)
        {
            DataSet ds = new DataSet();
            SqlConnection con = new SqlConnection(strcon);
            con.Open();

            try
            {
                if (con.State == ConnectionState.Closed)
                {
                    con.Open();

                }
                SqlCommand cmd = new SqlCommand("recievepayment", con);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.Add("@OfferID", SqlDbType.Int);
                cmd.Parameters["@OfferID"].Value = OfferID;

                cmd.ExecuteNonQuery();

                Response.Redirect("specifictriphistory.aspx");

                con.Close();

            }
            catch (Exception ex)
{

}

        }
        protected void finishtrip_click(object sender, EventArgs e)
        {
            DataSet ds = new DataSet();
            SqlConnection con = new SqlConnection(strcon);
            con.Open();

            try
            {
                if (con.State == ConnectionState.Closed)
                {
                    con.Open();

                }
                SqlCommand cmd = new SqlCommand("finishtrip", con);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.Add("@TripID", SqlDbType.Int);

                cmd.Parameters["@TripID"].Value = Session["TID"];

                cmd.ExecuteNonQuery();
                Response.Redirect("specifictriphistory.aspx");

                con.Close();

            }
            catch (Exception ex)
            {

            }

        }
        protected void getmyAcceptedOffer(ref int TripID , ref int OfferID)
        {
            DataSet ds = new DataSet();
            SqlConnection con = new SqlConnection(strcon);
            con.Open();

            try
            {
                if (con.State == ConnectionState.Closed)
                {
                    con.Open();

                }
                SqlCommand cmd = new SqlCommand("getmyAcceptedOffer", con);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.Add("@TripID", SqlDbType.Int);


                cmd.Parameters.Add("@output_OfferID", SqlDbType.Int).Direction = ParameterDirection.Output;

                cmd.Parameters["@TripID"].Value = TripID;
                cmd.ExecuteNonQuery();
                
                OfferID = Convert.ToInt32(cmd.Parameters["@output_OfferID"].Value);
                
                con.Close();

            }
            catch (Exception ex)
            {

            }

        }

    
        protected void getTripDetails(ref int TripID, ref String Country, ref string ArrivalDate, ref int totalRevenue, ref string tripStatus)
        {
            DataSet ds = new DataSet();
            SqlConnection con = new SqlConnection(strcon);
            con.Open();

            try
            {
                if (con.State == ConnectionState.Closed)
                {
                    con.Open();

                }
                SqlCommand cmd = new SqlCommand("getTripDetails", con);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.Add("@TripID", SqlDbType.Int);


                cmd.Parameters.Add("@output_Country", SqlDbType.VarChar, 60).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("@output_Arrival_date", SqlDbType.VarChar, 10).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("@output_TotalRevenue", SqlDbType.Int).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("@output_tripstatus", SqlDbType.VarChar, 15).Direction = ParameterDirection.Output;

                cmd.Parameters["@TripID"].Value = TripID;
                cmd.ExecuteNonQuery();

                Country = (String)cmd.Parameters["@output_Country"].Value;
                ArrivalDate = (String)cmd.Parameters["@output_Arrival_date"].Value;
                totalRevenue = Convert.ToInt32(cmd.Parameters["@output_TotalRevenue"].Value);
                tripStatus = (String)cmd.Parameters["@output_tripstatus"].Value;

                con.Close();

            }
            catch (Exception ex)
            {

            }

        }
    }
}