﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Globalization;
namespace Grabr
{
    public partial class WebForm9 : System.Web.UI.Page
    {
        string strcon = ConfigurationManager.ConnectionStrings["con"].ConnectionString;
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        protected void buttonClick(object sender, EventArgs e)
        {
            DataSet ds = new DataSet();
            SqlConnection con = new SqlConnection(strcon);
            con.Open();

            try
            {
                if (con.State == ConnectionState.Closed)
                {
                    con.Open();

                }
                SqlCommand cmd = new SqlCommand("planTrip", con);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.Add("@TravID", SqlDbType.VarChar, 3);
                cmd.Parameters.Add("@Country", SqlDbType.VarChar, 60);
                cmd.Parameters.Add("@Arrival_date", SqlDbType.VarChar, 10);

                cmd.Parameters["@TravID"].Value = Session["UserID"];
                cmd.Parameters["@Country"].Value = DropDownList1.SelectedItem.Value;

                cmd.Parameters["@Arrival_date"].Value = TextBox3.Text.Trim();

                cmd.ExecuteNonQuery();

                Response.Write("<script>alert('Trip Successfully Planned');</script>");
                Response.Redirect("travellerprofile.aspx");
                con.Close();

            }
            catch (Exception ex)
            {

            }
        }


    }
}