﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Grabr
{
    public partial class WebForm8 : System.Web.UI.Page
    {
        string strcon = ConfigurationManager.ConnectionStrings["con"].ConnectionString;
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            DataSet ds = new DataSet();
            SqlConnection con = new SqlConnection(strcon);
            con.Open();

            try
            {
                if (con.State == ConnectionState.Closed)
                {
                    con.Open();

                }

                SqlCommand cmd = new SqlCommand("placeorder", con);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.Add("@UserID", SqlDbType.VarChar, 3);
                cmd.Parameters.Add("@Country", SqlDbType.VarChar, 60);
                cmd.Parameters.Add("@ProductName", SqlDbType.VarChar, 50);
                cmd.Parameters.Add("@ProductPrice", SqlDbType.Int);



                cmd.Parameters["@UserID"].Value = Session["UserID"];
                cmd.Parameters["@Country"].Value = DropDownList1.SelectedItem.Value;
                cmd.Parameters["@ProductName"].Value = TextBox1.Text.Trim();
                cmd.Parameters["@ProductPrice"].Value = TextBox2.Text.Trim();


                cmd.ExecuteNonQuery();

                Response.Write("<script>alert('Order Placed Successfully');</script>");
                Response.Redirect("shopperprofile.aspx");
                con.Close();


            }
            catch (Exception ex)
            {

            }
        }
    }
}