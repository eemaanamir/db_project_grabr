﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Grabr
{
    public partial class WebForm13 : System.Web.UI.Page
    {
        string strcon = ConfigurationManager.ConnectionStrings["con"].ConnectionString;
        int OfferID1 = 0, OfferID2 = 0;
        protected void Page_Load(object sender, EventArgs e)
        {
            
            FirstTwoOffers(ref OfferID1, ref OfferID2);
            string TravNam1 = "";
            string TravNam2 = "";
            int Rating1 = 0, Rating2 = 0;
            DateTime Date1 = new DateTime() , Date2 = new DateTime();
            int cost1 = 0, cost2 = 0;

            if(OfferID1 != -1)
            {
                getOfferDetails(ref TravNam1, ref Rating1, ref Date1, ref cost1, ref OfferID1);
            }
            else
            {
                TravNam1 = "N/A";
                Date1 = DateTime.MinValue; 
            }
            if (OfferID2 != -1)
            {
                getOfferDetails(ref TravNam2, ref Rating2, ref Date2, ref cost2, ref OfferID2);
            }
            else
            {
                TravNam2 = "N/A";
                Date2 = DateTime.MinValue;
            }

            LinkButton1.Text = OfferID1.ToString();
            LinkButton2.Text = TravNam1;
            LinkButton3.Text = Rating1.ToString() + " Star";
            LinkButton4.Text = Date1.ToString("dd/M/yyyy");
            LinkButton5.Text = cost1.ToString() + " Rs";

            LinkButton6.Text = OfferID2.ToString();
            LinkButton7.Text = TravNam2;
            LinkButton8.Text = Rating2.ToString() + " Star";
            LinkButton9.Text = Date2.ToString("dd/M/yyyy");
            LinkButton10.Text = cost2.ToString() + " Rs";

            if(OfferID1 == -1)
            {
                Accept_Offer1.Visible = false;
            }
            else
            {
                Accept_Offer1.Visible = true;
            }
            if (OfferID2 == -1)
            {
                Accept_Offer2.Visible = false;
            }
            else
            {
                Accept_Offer2.Visible = true;
            }
        }


        protected void acceptOffer(ref int OfferID)
        {
            DataSet ds = new DataSet();
            SqlConnection con = new SqlConnection(strcon);
            con.Open();

            try
            {
                if (con.State == ConnectionState.Closed)
                {
                    con.Open();

                }
                SqlCommand cmd = new SqlCommand("acceptoffer", con);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.Add("@OfferID", SqlDbType.Int);
                cmd.Parameters.Add("@OrderID", SqlDbType.Int);

                
                cmd.Parameters["@OfferID"].Value = OfferID;
                cmd.Parameters["@OrderID"].Value = Session["OID"];

                cmd.ExecuteNonQuery();

                Response.Redirect("SpecificOrderHistory.aspx");

                con.Close();

            }
            catch (Exception ex)
            {

            }
        }
        protected void acceptOffer1(object sender, EventArgs e)
        {
            acceptOffer(ref OfferID1);
        }

        protected void acceptOffer2(object sender, EventArgs e)
        {
            acceptOffer(ref OfferID2);
        }
        protected void FirstTwoOffers(ref int OfferID1, ref int OfferID2)
        {
            DataSet ds = new DataSet();
            SqlConnection con = new SqlConnection(strcon);
            con.Open();

            try
            {
                if (con.State == ConnectionState.Closed)
                {
                    con.Open();

                }

                SqlCommand cmd = new SqlCommand("firsttwooffers", con);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.Add("@OrderID", SqlDbType.Int);

                cmd.Parameters.Add("@output_OfferID1", SqlDbType.Int).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("@output_OfferID2", SqlDbType.Int).Direction = ParameterDirection.Output;

                cmd.Parameters["@OrderID"].Value = Session["OID"];


                cmd.ExecuteNonQuery();

                OfferID1 = Convert.ToInt32(cmd.Parameters["@output_OfferID1"].Value);
                OfferID2 = Convert.ToInt32(cmd.Parameters["@output_OfferID2"].Value);

                con.Close();


            }
            catch (Exception ex)
            {

            }
        }
        protected void getOfferDetails(ref string TravNam , ref int Rating , ref DateTime date , ref int cost , ref int OfferID )
        {
            DataSet ds = new DataSet();
            SqlConnection con = new SqlConnection(strcon);
            con.Open();

            try
            {
                if (con.State == ConnectionState.Closed)
                {
                    con.Open();

                }

                SqlCommand cmd = new SqlCommand("getOfferDetails", con);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.Add("@OfferID", SqlDbType.Int);

                cmd.Parameters.Add("@output_travellerName", SqlDbType.VarChar,50).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("@output_rating", SqlDbType.Int).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("@output_Date", SqlDbType.Date).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("@output_shippingCost", SqlDbType.Int).Direction = ParameterDirection.Output;

                cmd.Parameters["@OfferID"].Value = OfferID;


                cmd.ExecuteNonQuery();

                TravNam = (string)cmd.Parameters["@output_travellerName"].Value;
                Rating = Convert.ToInt32(cmd.Parameters["@output_rating"].Value);
                date = (DateTime)cmd.Parameters["@output_Date"].Value;
                cost = Convert.ToInt32(cmd.Parameters["@output_shippingCost"].Value);

                con.Close();


            }
            catch (Exception ex)
            {

            }
        }
    }
}